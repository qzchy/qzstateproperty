﻿using QZCHY.Web.Framework.Mvc;

namespace QZCHY.API.Models.Media
{
    public class MediaModel : BaseQMEntityModel
    {
        public string Url { get; set; }
    }
}