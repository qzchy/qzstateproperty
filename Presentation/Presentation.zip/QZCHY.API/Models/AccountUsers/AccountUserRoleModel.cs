﻿using QZCHY.Web.Framework.Mvc;

namespace QZCHY.API.Models.AccountUsers
{
    public class AccountUserRoleModel : BaseQMEntityModel
    {
        public string Name { get; set; }
    }
}