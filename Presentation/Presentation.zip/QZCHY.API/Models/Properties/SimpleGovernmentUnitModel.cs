﻿using QZCHY.Web.Framework.Mvc;

namespace QZCHY.API.Models.Properties
{
    public class SimpleGovernmentUnitModel: BaseQMEntityModel
    {
        public string Name { get; set; }
    }
}